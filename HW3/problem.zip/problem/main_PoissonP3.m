clc; clear; close all; 
%% Parameters
h = zeros(1,1); NNdof = zeros(1,1);
ErrL2 = zeros(1,1);

%% Generate an initial mesh
BC = BCinput();
[node,elem] = squaremesh(BC.bounds,BC.h1,BC.h2);

%% Get the PDE data
pde = PoissonFC();

%% Finite element method
    % set boundary
    bdStruct = setboundary(node,elem);
    % solve the equation
    uh = PoissonP3(node,elem,pde,bdStruct);
    % record
    NNdof(1) = length(uh);
    h(1) = 1/(sqrt(size(node,1))-1);
    figure(1); 
    showresult(node,elem,uh);
    pause(1);
    % compute error
    ErrL2(1) = getL2error(node,elem,pde.uexact,uh);

%% Display error 
fprintf('\n');
fprintf('L2-norm of the error of uh:%0.8e\n\n',ErrL2);
