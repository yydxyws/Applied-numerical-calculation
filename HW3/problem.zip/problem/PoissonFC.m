function pde = PoissonFC()

pde = struct('uexact',@uexact, 'f',@f, 'g_D',@g_D);

% exact solution
    function val = uexact(p)
        x = p(:,1); y = p(:,2);
        val = sin(4*pi*x).*sin(4*pi*y);
    end

% right side hand function
    function val = f(p)
        x = p(:,1); y = p(:,2);
        val = -32 * pi^2 * sin(4*pi*x) .* sin(4*pi*y);
    end


% Dirichlet boundary conditions
    function val = g_D(p)
        x = p(:,1); y = p(:,2);
        val = sin(4*pi*x).*sin(4*pi*y);
    end
end