function BC = BCinput()
    % createMeshParams creates a structure to store mesh parameters and boundary conditions
    %
    % Inputs:
    %   a1, b1: x-direction range [a1, b1]
    %   a2, b2: y-direction range [a2, b2]
    %   h1: step size in the x direction
    %   h2: step size in the y direction
    %   neumannCondition: string specifying Neumann boundary condition
    %   dirichletCondition: string specifying Dirichlet boundary condition
    %
    % Output:
    %   meshParams: structure containing the mesh parameters and boundary conditions

    % Create the structure
    BC = struct();
    BC.bounds = [0, 1, 0, 1]; % [x_min, x_max, y_min, y_max]
    BC.h1 = 1/64;                  % Step size in x direction
    BC.h2 = 1/64;                  % Step size in y direction
end