
function u = Poisson(node,elem,pde,bdStruct)
% Poisson solves Poisson equation with P1 linear element (2D).
%
%    - Delta u = f   in \Omega, with
%    Dirichlet boundary conditions u = g_D on \Gamma_D,
%

N = size(node,1); NT = size(elem,1); Ndof = 3;
f = pde.f;

%% Assemble stiffness matrix
% 计算梯度基函数和单元面积：
% 	•	gradbasis 返回每个单元的基函数梯度 Dphi 和单元面积 area。
% 	•	局部刚度矩阵：
% 	•	对每个单元计算局部刚度矩阵：
% 
% K_{ij} = \int_{\text{单元}} \nabla \phi_i \cdot \nabla \phi_j \, dx.
% 
% 	•	全局刚度矩阵：
% 	•	使用 sparse 构造稀疏矩阵 kk，大小为 N \times N。
[Dphi,area] = gradbasis(node,elem);
K = zeros(NT,Ndof^2); % straighten
s = 1;
for i = 1:Ndof
    for j = 1:Ndof
        K(:,s) = sum(Dphi(:,:,i).*Dphi(:,:,j),2).*area;
        s = s+1;
    end
end
ii = reshape(repmat(elem, Ndof,1), [], 1);
jj = repmat(elem(:), Ndof, 1);
kk = sparse(ii,jj,K(:),N,N);

%% Assemble load vector
% 	•	高斯积分：
% 	•	使用 2 点高斯积分计算右端项。
% 	•	局部载荷向量：
% 	•	对每个单元计算右端项的局部贡献：
% 
% F_i = \int_{\text{单元}} f(x) \phi_i(x) \, dx.
% 
% 	•	全局载荷向量：
% 	•	使用 accumarray 将局部载荷向量装配到全局载荷向量 ff。
% Gauss quadrature rule
[lambda,weight] = quadpts(2);
F = zeros(NT,3); % straighten
for p = 1:length(weight)
    % quadrature points in the x-y coordinate
    pxy = lambda(p,1)*node(elem(:,1),:) ...
        + lambda(p,2)*node(elem(:,2),:) ...
        + lambda(p,3)*node(elem(:,3),:);
    fxy = f(pxy);  fv = fxy*lambda(p,:); % [f*phi1, f*phi2, f*phi3] at (xp,yp)
    F = F + weight(p)*fv;
end
F = repmat(area,1,3).*F;  % F = area.*F;
ff = accumarray(elem(:), F(:),[N 1]);


%% Apply Dirichlet boundary conditions
bdNodeIdx = bdStruct.bdNodeIdx; g_D = pde.g_D;
isBdNode = false(N,1); isBdNode(bdNodeIdx) = true;
bdDof = (isBdNode); freeDof = (~isBdNode);
nodeD = node(bdDof,:);
u = zeros(N,1); u(bdDof) = g_D(nodeD);
ff = ff - kk*u;

%% Set up solver 
u(freeDof) = kk(freeDof,freeDof)\ff(freeDof);

