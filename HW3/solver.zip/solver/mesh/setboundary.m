
function bdStruct= setboundary(node,elem)
% returns structure of boundary
% information. 


%% Find boundary edges
allEdge = [elem(:,[2,3]); elem(:,[3,1]); elem(:,[1,2])];
totalEdge = sort(allEdge,2);

% counterclockwise bdEdge
[~, i1] = unique(totalEdge,'rows');     % first occurrence
[~, i2] = unique(totalEdge(end:-1:1,:),'rows');  
i2 = size(totalEdge,1)+1-i2;            % last occurrence
bdEdge = allEdge(i1(i1==i2),:);

bdStruct.bdEdge = bdEdge;   % all boundary edges
bdStruct.bdEdgeD = bdEdge; % Dirichlet boundary edges
bdStruct.bdNodeIdx = unique(bdEdge(:)); % Dirichlet boundary nodes

bdEdgeIdx = find(i1==i2);      % indices of all boundary edges
bdStruct.bdEdgeIdx = bdEdgeIdx; 
bdStruct.bdEdgeIdxD = bdEdgeIdx; 
