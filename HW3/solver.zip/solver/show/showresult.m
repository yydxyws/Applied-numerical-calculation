function showresult(node,elem,uh)
%showresult displays the mesh and the solution
%

clf;  % clear figures
set(gcf,'Units','normal');
set(gcf,'Position',[0.1,0.2,0.8,0.6]);

%% Plot mesh
subplot(1,2,1);
showmesh(node,elem);

%% Plot numerical solution
subplot(1,2,2);
showsolution(node,elem,uh(1:size(node,1),1));
