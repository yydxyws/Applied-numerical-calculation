function showmesh(node,elem,options)
%Showmesh displays a 2D triangular mesh.
%
% Inputs:
%   node   - Nx2 matrix, each row represents the coordinates of a node.
%   elem   - Mx3 matrix, each row contains indices of nodes forming a triangle.
%   options (optional) - structure with display options:
%       FaceAlpha - transparency of the mesh faces (default: 0.4).
%       facecolor - color of the mesh faces (default: [0.5 0.9 0.45]).

% Set default options
if nargin < 3
    options.FaceAlpha = 0.4;
    options.facecolor = [0.5 0.9 0.45];
end

% Validate inputs
dim = size(node, 2);
if dim ~= 2
    error('The function only supports 2D triangular meshes.');
end

% Plot the triangular mesh
h = patch('Faces', elem, 'Vertices', node, ...
          'FaceColor', options.facecolor, ...
          'EdgeColor', 'k', ...
          'FaceAlpha', options.FaceAlpha);

% Adjust display settings
axis equal;
axis tight;
title('2D Triangular Mesh');
xlabel('X');
ylabel('Y');
end